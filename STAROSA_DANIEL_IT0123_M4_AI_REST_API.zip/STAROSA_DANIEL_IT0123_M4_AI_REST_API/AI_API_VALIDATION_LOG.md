# AI and API Validation Log

Student: Daniel A. Sta. Rosa  Section: TN32  Date: __________

Approved AI tool: ChatGPT

Do not paste a username, password, bearer token, API key, Authorization header,
X-API-KEY value, or private response data into this file or an AI tool.

| Request | Pre-AI prediction | Sanitized AI prompt | AI recommendation | Decision (Accepted/Modified/Rejected) | Simulator/Postman evidence |
|---|---|---|---|---|---|
| R1 | method:"GET" path:"http://library.demo.local/api/v1/books" auth:"none" expected_status:"200" | | | | |
| R2 | method:"GET" path:"http://library.demo.local/api/v1/books" auth:"none" query_parameters:{IncludeISBN=true, SortBy=author} expected_status:"200"| | | | |
| R3 | method:"POST" path:"http://library.demo.local/api/v1/loginViaBasic" auth:"basic-auth" expected_status:"200"| | | | |
| R4 | method:"POST" path:"http://library.demo.local/api/v1/books" auth:"x-api-key" payload:{"id": 0,"title": "string","author": "string"} expected_status:"200"| | | | |
| R5 | method:"GET" path:"http://library.demo.local/api/v1/books/{id}" auth:"none" expected_status:"200"| | | | |
| R6 | method:"DELETE" path:"http://library.demo.local/api/v1/books/{id}" auth:"x-api-key" expected_status:"200"| | | | |
| R7 | method:"POST" path:"http://library.demo.local/api/v1/books/" auth:"missing-or-invalid-key" payload:{"id": 0,"title": "string","author": "string"} expected_status:"401"| | | | |

## Python script review

- Sanitized excerpt reviewed (credential values replaced with placeholders):
- What the script automates:
- AI recommendation evaluated:
- Decision and technical reason:
- Independent validation performed:

## AI-use disclosure

- Assistance received:
- Checks performed before accepting suggestions:
- Revisions made by the student:
- One limitation or error found in the AI response:
